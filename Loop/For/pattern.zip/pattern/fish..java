import java.util.Scanner;
class Fish
{
	public static void main(String[]args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number of row ");
		int row = sc.nextInt();		
		
		for(int i =1;i<=row;i++)
		{
			
			System.out.print("\n");
		}		
	}
}