/*
*
* *
* * * *
* * * * * * *
* * * * * * * * * * * 
*/

import java.util.Scanner;
class Pattern_22
{
	public static void main(String[]args)
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter any number");
		int row = sc.nextInt();
		int k=1;
		for(int i=1;i<=row;i++)
		{
			for(int j=1;j<=k;j++)
			{
				System.out.print("* ");
			}
			k=k+i;
			System.out.println("");
		}
	}
}